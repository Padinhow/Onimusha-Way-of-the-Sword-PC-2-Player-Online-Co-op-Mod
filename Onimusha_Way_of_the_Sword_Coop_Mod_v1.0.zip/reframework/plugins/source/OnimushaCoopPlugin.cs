// ============================================================================
// Onimusha: Way of the Sword (RE Engine / TDB v82) — 2-Player Online Co-op Mod
// Architecture: cranebeaker/coop-anything (REFramework.NET C# Source Plugin)
// Target Binary: OnimushaWotS.exe v1.0.1.0 (TDB v82 @ 0x98E2E30)
// ============================================================================
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using Hexa.NET.ImGui;
using REFrameworkNET;
using REFrameworkNET.Attributes;
using REFrameworkNET.Callbacks;

namespace OnimushaWotSCoop
{
    public enum SessionRole
    {
        Offline = 0,
        Host = 1,
        Client = 2,
        BotTest = 3 // Single-instance local Bot Peer for automated QA (playbook/automated-qa.md)
    }

    public enum PacketType : byte
    {
        PlayerState = 0x01,
        EnemyPose = 0x02,
        OwnershipTransfer = 0x03,
        OwnershipAck = 0x04,
        OwnershipCommit = 0x05,
        HitCommit = 0x06,
        StoryEffect = 0x07,
        ReviveEvent = 0x08,
        Ping = 0x09
    }

    // Verified Musashi DLC / Costume IDs present in dlc/ & steam_settings/configs.app.ini
    public static class MusashiOutfits
    {
        public const int DefaultRonin = 0;
        public const int HellfireHaori = 3935720;
        public const int MoonlightHaori = 3935730;
        public const int RedArmor = 3935740;
        public const int CloudbiterHaori = 4053020;
        public const int GauntletCrimsonLotus = 3935760;

        public static readonly (int Id, string Name)[] Catalog = new[]
        {
            (CloudbiterHaori, "Cloudbiter Haori (4053020)"),
            (RedArmor, "Red Armor (3935740)"),
            (MoonlightHaori, "Moonlight Haori (3935730)"),
            (HellfireHaori, "Hellfire Haori (3935720)"),
            (DefaultRonin, "Padrao (Miyamoto Musashi)")
        };
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct WireHeader
    {
        public ushort Magic;      // 0x4F4E ('ON')
        public byte Version;      // 1
        public PacketType Type;
        public byte SenderPeer;   // 0 = Host, 1 = Guest
        public byte Flags;
        public uint Seq;
        public uint Ack;
        public uint AckBits;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct PlayerStatePayload
    {
        public float PosX, PosY, PosZ;
        public float RotX, RotY, RotZ, RotW;
        public float VelX, VelY, VelZ;
        public uint MotionBankId;
        public uint MotionId;
        public float MotionFrame;
        public int EquipBodyId;
        public int EquipCloakId;
        public int EquipWeaponsId;
        public int EquipGauntletId;
        public float Health;
        public float MaxHealth;
        public float Rikido;
        public byte IsDowned;
        public byte IsOniMode;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HitCommitPayload
    {
        public int EnemyUniqueId;     // app.cEnemyContextParam.get_Unique()
        public int Epoch;             // Monotonic ownership epoch fence
        public float HealthDamage;    // Applied via app.cHealthManager.addHealth(-dmg)
        public float RikidoDamage;    // Applied via app.cCharacterRikidoSupporter.applyDamage
        public int GaugeIndex;        // app.cHealthManager.get_CurrentGaugeIndex() (multi-bar Boss HP)
        public byte TriggerRikidoBreak;
        public byte TriggerIssenKill;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct StoryEffectPayload
    {
        public byte OriginPeer;
        public uint EffectSeq;
        public byte EffectKind; // 1=StoryFlag, 2=MissionStatus, 3=MiasmaClear, 4=WarpMirror, 5=SharedRedSouls
        public int KeyId;
        public int IntVal;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct ViaVec3
    {
        public float X, Y, Z, Pad;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct ViaQuat
    {
        public float X, Y, Z, W;
    }

    /// <summary>
    /// Dynamic Actor Ownership with Monotonic Epochs (playbook/actor-ownership.md).
    /// Ensures the player closest to a Genma/Boss owns its local timing for zero-latency Parry/JustGuard/Issen.
    /// </summary>
    public sealed class ActorOwnershipManager
    {
        public const float HoldTimeSec = 1.5f;
        public const float HysteresisRatio = 0.75f;

        public sealed class Lease
        {
            public int EnemyUniqueId;
            public byte OwnerPeer;
            public int Epoch = 1;
            public int PendingOwner = -1;
            public int PendingEpoch;
            public double LastSwitchTime = -10.0;
        }

        private readonly Dictionary<int, Lease> _leases = new();
        public int StalePacketsRejected { get; private set; }
        public int TrackedCount => _leases.Count;

        public Lease GetOrCreate(int enemyUniqueId)
        {
            if (!_leases.TryGetValue(enemyUniqueId, out var lease))
            {
                lease = new Lease { EnemyUniqueId = enemyUniqueId, OwnerPeer = 0, Epoch = 1 };
                _leases[enemyUniqueId] = lease;
            }
            return lease;
        }

        public bool ValidateIncoming(int enemyUniqueId, byte senderPeer, int packetEpoch)
        {
            var lease = GetOrCreate(enemyUniqueId);
            if (packetEpoch < lease.Epoch || senderPeer != lease.OwnerPeer)
            {
                StalePacketsRejected++;
                return false;
            }
            return true;
        }

        public void ApplyCommit(int enemyUniqueId, byte newOwner, int newEpoch, double now)
        {
            var lease = GetOrCreate(enemyUniqueId);
            if (newEpoch >= lease.Epoch)
            {
                lease.OwnerPeer = newOwner;
                lease.Epoch = newEpoch;
                lease.PendingOwner = -1;
                lease.LastSwitchTime = now;
            }
        }
    }

    /// <summary>
    /// Non-blocking UDP Transport (Primary for Goldberg/LAN/VPN + Compatible with Steam Spacewar Sidecar Relay).
    /// </summary>
    public sealed class CoopUdpTransport : IDisposable
    {
        private UdpClient? _udp;
        private IPEndPoint? _remoteEp;
        private uint _localSeq;
        private uint _remoteMaxSeq;
        private uint _ackBits;

        public int PacketsSent { get; private set; }
        public int PacketsReceived { get; private set; }
        public bool IsActive => _udp != null;

        public void StartHost(int port = 27095)
        {
            Stop();
            _udp = new UdpClient(port);
            _udp.Client.Blocking = false;
        }

        public void ConnectClient(string hostIp, int port = 27095)
        {
            Stop();
            _udp = new UdpClient(0);
            _udp.Client.Blocking = false;
            _remoteEp = new IPEndPoint(IPAddress.Parse(hostIp), port);
        }

        public void Send<T>(PacketType type, byte senderPeer, in T payload) where T : struct
        {
            if (_udp == null || _remoteEp == null) return;
            int hdrSize = Marshal.SizeOf<WireHeader>();
            int payloadSize = Marshal.SizeOf<T>();
            byte[] buf = new byte[hdrSize + payloadSize];
            var hdr = new WireHeader
            {
                Magic = 0x4F4E,
                Version = 1,
                Type = type,
                SenderPeer = senderPeer,
                Flags = 0,
                Seq = ++_localSeq,
                Ack = _remoteMaxSeq,
                AckBits = _ackBits
            };
            MemoryMarshal.Write(buf.AsSpan(0, hdrSize), in hdr);
            T copy = payload;
            MemoryMarshal.Write(buf.AsSpan(hdrSize, payloadSize), in copy);
            try
            {
                _udp.Send(buf, buf.Length, _remoteEp);
                PacketsSent++;
            }
            catch (SocketException) { }
        }

        public bool TryReceive(out WireHeader header, out byte[] payload, out IPEndPoint? sender)
        {
            header = default;
            payload = Array.Empty<byte>();
            sender = null;
            if (_udp == null) return false;
            try
            {
                if (_udp.Available <= 0) return false;
                IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                byte[] raw = _udp.Receive(ref ep);
                int hdrSize = Marshal.SizeOf<WireHeader>();
                if (raw.Length < hdrSize) return false;
                header = MemoryMarshal.Read<WireHeader>(raw.AsSpan(0, hdrSize));
                if (header.Magic != 0x4F4E || header.Version != 1) return false;
                _remoteEp ??= ep;
                sender = ep;
                PacketsReceived++;
                if (header.Seq > _remoteMaxSeq)
                {
                    int shift = (int)(header.Seq - _remoteMaxSeq);
                    _ackBits = shift >= 32 ? 1u : ((_ackBits << shift) | 1u);
                    _remoteMaxSeq = header.Seq;
                }
                int payloadLen = raw.Length - hdrSize;
                payload = new byte[payloadLen];
                Buffer.BlockCopy(raw, hdrSize, payload, 0, payloadLen);
                return true;
            }
            catch (SocketException)
            {
                return false;
            }
        }

        public void Stop()
        {
            try { _udp?.Close(); } catch { }
            _udp = null;
            _remoteEp = null;
        }

        public void Dispose() => Stop();
    }

    /// <summary>
    /// Core Co-op Controller binding to Onimusha: Way of the Sword TDB v82 Singletons & Entities.
    /// </summary>
    public sealed class OnimushaCoopCore
    {
        public SessionRole Role { get; set; } = SessionRole.Offline;
        public string TargetIp { get; set; } = "127.0.0.1";
        public int Port { get; set; } = 27095;
        public int SelectedOutfitIndex { get; set; } = 0;
        public int PartnerOutfitId { get; set; } = MusashiOutfits.CloudbiterHaori;
        public int PartnerGauntletId { get; set; } = MusashiOutfits.GauntletCrimsonLotus;
        public float EnemyHpMultiplier { get; set; } = 1.50f;
        public float EnemyRikidoMultiplier { get; set; } = 1.35f;
        public bool ShareRedSouls100Percent { get; set; } = true;
        public bool EnableDownedRevive { get; set; } = true;
        public bool SaveGuardActive { get; set; } = true;
        public bool ShowOverlayWindow { get; set; } = true; // Visible without needing Insert key!

        // Runtime State
        public PlayerStatePayload LocalState;
        public PlayerStatePayload RemoteState;
        public bool LocalIsDowned;
        public bool RemoteIsDowned;
        public float ReviveProgressSec;
        public const float ReviveRequiredSec = 3.0f;
        public const float ReviveRadiusMeters = 2.5f;

        // TDB v82 Resolved Singleton & Clone Status
        public bool PlayerManagerFound { get; set; }
        public bool EnemyManagerFound { get; set; }
        public bool SoulManagerFound { get; set; }
        public bool StoryManagerFound { get; set; }
        public bool WarpMirrorFound { get; set; }
        public ulong LocalPlayerAddress { get; set; }
        public ulong PartnerCloneAddress { get; set; }
        public ManagedObject? PartnerCloneObject { get; set; }
        public ManagedObject? PartnerContext { get; set; }
        public int LastAppliedPartnerOutfit { get; set; } = -1;
        public uint LastAppliedMotionId { get; set; } = uint.MaxValue;
        private bool _requestedPlayerUiCreation;
        public int SaveGuardBlockedCount { get; private set; }
        public int SharedRedSoulsTotal { get; private set; }

        public readonly ActorOwnershipManager Ownership = new();
        public readonly CoopUdpTransport Transport = new();
        private readonly HashSet<(byte Origin, uint Seq)> _appliedEffects = new();
        private uint _nextEffectSeq = 1;
        private readonly double _startTime = DateTime.UtcNow.TimeOfDay.TotalSeconds;
        private bool _suppressHookReentry;

        // Flight Recorder Log (playbook/automated-qa.md)
        private StreamWriter? _flightLog;

        public void StartFlightRecorder(string logDir)
        {
            try
            {
                Directory.CreateDirectory(logDir);
                string path = Path.Combine(logDir, $"onimusha_coop_flight_{DateTime.Now:yyyyMMdd_HHmmss}.jsonl");
                _flightLog = new StreamWriter(path, append: true, Encoding.UTF8) { AutoFlush = true };
                LogEvent("SESSION_INIT", $"role={Role} outfit={PartnerOutfitId} hpMult={EnemyHpMultiplier} rkMult={EnemyRikidoMultiplier}");
            }
            catch { }
        }

        public void LogEvent(string eventName, string detail)
        {
            try
            {
                double elapsed = DateTime.UtcNow.TimeOfDay.TotalSeconds - _startTime;
                _flightLog?.WriteLine($"{{\"t\":{elapsed:F3},\"ev\":\"{eventName}\",\"detail\":\"{detail}\"}}");
            }
            catch { }
        }

        public void CyclePartnerOutfit()
        {
            SelectedOutfitIndex = (SelectedOutfitIndex + 1) % MusashiOutfits.Catalog.Length;
            PartnerOutfitId = MusashiOutfits.Catalog[SelectedOutfitIndex].Id;
            LogEvent("P2_OUTFIT_CYCLE", $"id={PartnerOutfitId} name={MusashiOutfits.Catalog[SelectedOutfitIndex].Name}");
        }

        public bool ShouldBlockGameSave(string saveMethodName)
        {
            if (SaveGuardActive || Role == SessionRole.Client || Role == SessionRole.BotTest)
            {
                SaveGuardBlockedCount++;
                LogEvent("SAVE_GUARD_BLOCKED", saveMethodName);
                return true;
            }
            return false;
        }

        public bool OnLocalPlayerFatalDamage(ref float healthToSet)
        {
            if (!EnableDownedRevive || Role == SessionRole.Offline) return false;
            if (!RemoteIsDowned && RemoteState.Health > 0f)
            {
                healthToSet = 1.0f;
                LocalIsDowned = true;
                ReviveProgressSec = 0f;
                LogEvent("PLAYER_DOWNED", "local_player_clamped_at_1hp_awaiting_revive");
                return true;
            }
            return false;
        }

        public void BroadcastSharedRedSouls(int soulAmount)
        {
            if (_suppressHookReentry || !ShareRedSouls100Percent || Role == SessionRole.Offline || soulAmount <= 0)
                return;
            byte selfPeer = (byte)(Role == SessionRole.Client ? 1 : 0);
            var pkt = new StoryEffectPayload
            {
                OriginPeer = selfPeer,
                EffectSeq = _nextEffectSeq++,
                EffectKind = 5, // SharedRedSouls
                KeyId = 0,
                IntVal = soulAmount
            };
            _appliedEffects.Add((pkt.OriginPeer, pkt.EffectSeq));
            SharedRedSoulsTotal += soulAmount;
            Transport.Send(PacketType.StoryEffect, selfPeer, in pkt);
            LogEvent("SHARED_RED_SOULS_TX", $"amount={soulAmount}");
        }

        public void BroadcastStoryFlag(int flagId, int isSet)
        {
            if (_suppressHookReentry || Role == SessionRole.Offline)
                return;
            byte selfPeer = (byte)(Role == SessionRole.Client ? 1 : 0);
            var pkt = new StoryEffectPayload
            {
                OriginPeer = selfPeer,
                EffectSeq = _nextEffectSeq++,
                EffectKind = 1, // StoryFlag
                KeyId = flagId,
                IntVal = isSet
            };
            _appliedEffects.Add((pkt.OriginPeer, pkt.EffectSeq));
            Transport.Send(PacketType.StoryEffect, selfPeer, in pkt);
            LogEvent("STORY_FLAG_TX", $"flag={flagId} val={isSet}");
        }

        public void ApplyRemoteSharedRedSouls(ManagedObject? soulMgr, int amount)
        {
            if (soulMgr == null || amount <= 0) return;
            try
            {
                _suppressHookReentry = true;
                var td = soulMgr.GetTypeDefinition();
                var m = td?.FindMethod("addSoulAmountReserve");
                m?.Invoke(soulMgr, new object[] { amount });
                SharedRedSoulsTotal += amount;
                LogEvent("SHARED_RED_SOULS_RX", $"amount={amount}");
            }
            catch { }
            finally
            {
                _suppressHookReentry = false;
            }
        }

        /// <summary>
        /// Reads local Player 1 Transform (via.Transform), Motion (via.motion.TreeLayer), and Equipment (app.cPlayerContextParam).
        /// </summary>
        public void SyncLocalPlayerFromEngine(ManagedObject playerMgr)
        {
            try
            {
                var pm = playerMgr.As<app.PlayerManager>();
                if (pm == null) return;

                app.cPlayerManageInfo? manageInfoProxy = pm.getControllingPlayerInfo();
                if (manageInfoProxy == null && pm._PlayerInfoList != null && pm._PlayerInfoList.Count > 0)
                {
                    manageInfoProxy = pm._PlayerInfoList[0];
                }
                if (manageInfoProxy == null) return;

                ManagedObject? p1GoMo = (manageInfoProxy.Object as IProxy)?.GetInstance() as ManagedObject;
                if (p1GoMo != null)
                {
                    LocalPlayerAddress = p1GoMo.GetAddress();
                    ReadTransformAndMotion(p1GoMo, ref LocalState);
                }

                var playerCtx = manageInfoProxy.Context?.Player;
                if (playerCtx != null)
                {
                    LocalState.EquipBodyId = playerCtx.CurrentEquipBodyID;
                    LocalState.EquipWeaponsId = playerCtx.CurrentEquipWeaponsID;
                    LocalState.EquipGauntletId = playerCtx.CurrentEquipGauntletID;
                }

                if (Role != SessionRole.Offline && p1GoMo != null)
                {
                    var existingCloneProxy = PartnerCloneObject?.As<via.GameObject>();
                    if (PartnerCloneObject == null || existingCloneProxy == null || !existingCloneProxy.Valid)
                    {
                        PartnerCloneObject = null;
                        PartnerCloneAddress = 0;
                        TrySpawnPartnerMusashiClone(pm);
                    }

                    if (PartnerCloneObject != null)
                    {
                        ApplyRemoteStateToPartnerClone(pm, p1GoMo);
                    }
                }
            }
            catch { }
        }

        private void ReadTransformAndMotion(ManagedObject gameObj, ref PlayerStatePayload state)
        {
            var goProxy = gameObj.As<via.GameObject>();
            var transform = goProxy?.Transform;
            if (transform != null)
            {
                via.vec3 pos = transform.Position;
                state.PosX = pos.x;
                state.PosY = pos.y;
                state.PosZ = pos.z;

                via.Quaternion rot = transform.Rotation;
                state.RotX = rot.x;
                state.RotY = rot.y;
                state.RotZ = rot.z;
                state.RotW = rot.w;
            }

            var goTd = gameObj.GetTypeDefinition();
            var motionType = TDB.Get()?.FindType("via.motion.Motion")?.GetRuntimeType();
            if (motionType != null)
            {
                object? motComp = null;
                if (goTd?.FindMethod("getComponent(System.Type)")?.HandleInvokeMember_Internal(gameObj, new object[] { motionType }, ref motComp) == true && motComp is ManagedObject mot)
                {
                    object? layerObj = null;
                    if (mot.GetTypeDefinition()?.FindMethod("getLayer")?.HandleInvokeMember_Internal(mot, new object[] { 0u }, ref layerObj) == true && layerObj is ManagedObject layer)
                    {
                        var lTd = layer.GetTypeDefinition();
                        object? mb = null, mid = null, fr = null;
                        if (lTd?.FindMethod("get_MotionBankID")?.HandleInvokeMember_Internal(layer, Array.Empty<object>(), ref mb) == true && mb is uint mbVal)
                            state.MotionBankId = mbVal;
                        if (lTd?.FindMethod("get_MotionID")?.HandleInvokeMember_Internal(layer, Array.Empty<object>(), ref mid) == true && mid is uint midVal)
                            state.MotionId = midVal;
                        if (lTd?.FindMethod("get_Frame")?.HandleInvokeMember_Internal(layer, Array.Empty<object>(), ref fr) == true && fr is float frVal)
                            state.MotionFrame = frVal;
                    }
                }
            }
        }

        private void TrySpawnPartnerMusashiClone(app.PlayerManager pm)
        {
            try
            {
                var uiGoProxy = pm.getControllingPlayerUI();
                if (uiGoProxy == null)
                {
                    if (!_requestedPlayerUiCreation && !pm._IsCreatingPlayerUI)
                    {
                        _requestedPlayerUiCreation = true;
                        pm.createPlayerUI();
                        LogEvent("P2_CLONE_UI_REQUESTED", $"outfit={PartnerOutfitId}");
                    }
                    return;
                }

                var cloneGo = (uiGoProxy as IProxy)?.GetInstance() as ManagedObject;
                if (cloneGo != null)
                {
                    cloneGo.Globalize();
                    pm.setDrawPlayerUI(true);
                    uiGoProxy.DrawSelf = true;
                    uiGoProxy.UpdateSelf = true;

                    PartnerCloneObject = cloneGo;
                    PartnerCloneAddress = cloneGo.GetAddress();
                    LastAppliedPartnerOutfit = -1;
                    LastAppliedMotionId = uint.MaxValue;
                    _requestedPlayerUiCreation = false;
                    LogEvent("P2_CLONE_SPAWNED", $"addr=0x{PartnerCloneAddress:X} outfit={PartnerOutfitId}");
                }
            }
            catch (Exception ex)
            {
                LogEvent("P2_CLONE_SPAWN_WARN", ex.Message);
            }
        }

        private void ApplyRemoteStateToPartnerClone(app.PlayerManager pm, ManagedObject p1GoMo)
        {
            if (PartnerCloneObject == null) return;
            try
            {
                var cloneGoProxy = PartnerCloneObject.As<via.GameObject>();
                if (cloneGoProxy == null || !cloneGoProxy.Valid) return;

                pm.setDrawPlayerUI(true);
                cloneGoProxy.DrawSelf = true;

                int desiredOutfit = Role == SessionRole.BotTest ? PartnerOutfitId : (RemoteState.EquipBodyId != 0 ? RemoteState.EquipBodyId : PartnerOutfitId);
                if (desiredOutfit != LastAppliedPartnerOutfit && desiredOutfit != 0 && pm.isPlayerUICreateComplete() && !pm.isChangingModelPlayerUI())
                {
                    pm.requestChangeModelPlayerUI(app.PlayerPartsDef.PARTS_TYPE.BODY, desiredOutfit);
                    LastAppliedPartnerOutfit = desiredOutfit;
                    LogEvent("P2_CLONE_OUTFIT_APPLIED", $"outfit={desiredOutfit}");
                }

                var transform = cloneGoProxy.Transform;
                if (transform != null)
                {
                    via.vec3 pos = transform.Position;
                    pos.x = RemoteState.PosX;
                    pos.y = RemoteState.PosY;
                    pos.z = RemoteState.PosZ;
                    transform.Position = pos;

                    if (Role == SessionRole.BotTest)
                    {
                        var p1Transform = p1GoMo.As<via.GameObject>()?.Transform;
                        if (p1Transform != null)
                        {
                            transform.copyJointsLocalMatrix(p1Transform);
                        }
                    }
                }

                var goTd = PartnerCloneObject.GetTypeDefinition();
                var motionType = TDB.Get()?.FindType("via.motion.Motion")?.GetRuntimeType();
                if (motionType != null)
                {
                    object? motComp = null;
                    if (goTd?.FindMethod("getComponent(System.Type)")?.HandleInvokeMember_Internal(PartnerCloneObject, new object[] { motionType }, ref motComp) == true && motComp is ManagedObject mot)
                    {
                        object? layerObj = null;
                        if (mot.GetTypeDefinition()?.FindMethod("getLayer")?.HandleInvokeMember_Internal(mot, new object[] { 0u }, ref layerObj) == true && layerObj is ManagedObject layer)
                        {
                            var lTd = layer.GetTypeDefinition();
                            if (RemoteState.MotionId != LastAppliedMotionId)
                            {
                                lTd?.FindMethod("set_MotionBankID")?.Invoke(layer, new object[] { RemoteState.MotionBankId });
                                lTd?.FindMethod("set_MotionID")?.Invoke(layer, new object[] { RemoteState.MotionId });
                                LastAppliedMotionId = RemoteState.MotionId;
                            }
                            lTd?.FindMethod("set_Frame")?.Invoke(layer, new object[] { RemoteState.MotionFrame });
                        }
                    }
                }
            }
            catch { }
        }

        public void UpdateBotPeer(float dt)
        {
            if (Role != SessionRole.BotTest) return;
            double t = DateTime.UtcNow.TimeOfDay.TotalSeconds;
            float targetOffsetX = LocalIsDowned ? 1.0f : (float)(Math.Cos(t * 1.2) * 2.2);
            float targetOffsetZ = LocalIsDowned ? 1.0f : (float)(Math.Sin(t * 1.2) * 2.2);

            RemoteState.PosX = LocalState.PosX + targetOffsetX;
            RemoteState.PosY = LocalState.PosY;
            RemoteState.PosZ = LocalState.PosZ + targetOffsetZ;
            RemoteState.RotX = LocalState.RotX;
            RemoteState.RotY = LocalState.RotY;
            RemoteState.RotZ = LocalState.RotZ;
            RemoteState.RotW = LocalState.RotW;
            RemoteState.MotionBankId = LocalState.MotionBankId;
            RemoteState.MotionId = LocalState.MotionId;
            RemoteState.MotionFrame = LocalState.MotionFrame;
            RemoteState.EquipBodyId = PartnerOutfitId;
            RemoteState.EquipGauntletId = PartnerGauntletId;
            RemoteState.EquipWeaponsId = LocalState.EquipWeaponsId;
            RemoteState.Health = 1000f;
            RemoteState.MaxHealth = 1000f;
            RemoteState.IsDowned = 0;

            if (LocalIsDowned)
            {
                ReviveProgressSec += dt;
                if (ReviveProgressSec >= ReviveRequiredSec)
                {
                    LocalIsDowned = false;
                    ReviveProgressSec = 0f;
                    LogEvent("BOT_REVIVED_LOCAL_PLAYER", "health_restored_50pct");
                }
            }
        }

        public void ProcessNetworkIncoming(ManagedObject? soulMgr, ManagedObject? storyMgr)
        {
            while (Transport.TryReceive(out var hdr, out var payload, out IPEndPoint? unusedEp))
            {
                switch (hdr.Type)
                {
                    case PacketType.PlayerState:
                        int psSize = Marshal.SizeOf<PlayerStatePayload>();
                        if (payload.Length >= psSize)
                        {
                            RemoteState = MemoryMarshal.Read<PlayerStatePayload>(payload.AsSpan(0, psSize));
                            RemoteIsDowned = RemoteState.IsDowned != 0;
                        }
                        break;

                    case PacketType.HitCommit:
                        int hcSize = Marshal.SizeOf<HitCommitPayload>();
                        if (payload.Length >= hcSize)
                        {
                            var hit = MemoryMarshal.Read<HitCommitPayload>(payload.AsSpan(0, hcSize));
                            if (Ownership.ValidateIncoming(hit.EnemyUniqueId, hdr.SenderPeer, hit.Epoch))
                            {
                                LogEvent("HIT_COMMIT_RX", $"enemy={hit.EnemyUniqueId} hpDmg={hit.HealthDamage:F1} rkDmg={hit.RikidoDamage:F1}");
                            }
                        }
                        break;

                    case PacketType.StoryEffect:
                        int seSize = Marshal.SizeOf<StoryEffectPayload>();
                        if (payload.Length >= seSize)
                        {
                            var eff = MemoryMarshal.Read<StoryEffectPayload>(payload.AsSpan(0, seSize));
                            if (_appliedEffects.Add((eff.OriginPeer, eff.EffectSeq)))
                            {
                                if (eff.EffectKind == 5)
                                    ApplyRemoteSharedRedSouls(soulMgr, eff.IntVal);
                                else if (eff.EffectKind == 1 && storyMgr != null)
                                {
                                    _suppressHookReentry = true;
                                    try
                                    {
                                        var stTd = storyMgr.GetTypeDefinition();
                                        stTd?.FindMethod(eff.IntVal != 0 ? "onStoryFlag" : "offStoryFlag")?.Invoke(storyMgr, new object[] { eff.KeyId });
                                    }
                                    finally
                                    {
                                        _suppressHookReentry = false;
                                    }
                                }
                            }
                        }
                        break;
                }
            }
        }
    }

    /// <summary>
    /// REFramework.NET Entry Point, Method Hooks (TDB v82), ImGui Overlay & Local UDP QA RPC Bridge.
    /// Includes Keyboard Hotkeys that do NOT require an Insert key!
    /// </summary>
    public static class OnimushaCoopPlugin
    {
        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(int vKey);

        // Virtual Key Codes (Works on 60%, TKL, and Full keyboards without Insert)
        private const int VK_F5 = 0x74;
        private const int VK_F6 = 0x75;
        private const int VK_F7 = 0x76;
        private const int VK_F8 = 0x77;
        private const int VK_OEM_PLUS = 0xBB;   // '=' / '+' key next to Backspace
        private const int VK_OEM_MINUS = 0xBD;  // '-' key next to '0'
        private const int VK_OEM_4 = 0xDB;      // '[' key
        private const int VK_OEM_6 = 0xDD;      // ']' key

        public static readonly OnimushaCoopCore Core = new();
        private static readonly List<MethodHook> _installedHooks = new();
        private static readonly Dictionary<int, bool> _keyWasDown = new();
        private static UdpClient? _qaRpcSocket;
        private static DateTime _lastTick = DateTime.UtcNow;

        [PluginEntryPoint]
        public static void Main()
        {
            API.LogInfo("[OnimushaWotSCoop] Initializing 2-Player Co-op Plugin (TDB v82)...");
            Core.StartFlightRecorder(@"X:\Onimusha.Way.of.the.Sword-CoopTest\reframework\logs");
            InstallTdbHooks();
            StartQaRpcBridge();
            API.LogInfo("[OnimushaWotSCoop] Initialized. Hotkeys active: '=' or F8 (Menu), '-' or F6 (Bot Mode), ']' or F7 (Outfit), '[' or F5 (Host).");
        }

        [PluginExitPoint]
        public static void OnUnload()
        {
            API.LogInfo("[OnimushaWotSCoop] Unloading plugin and releasing resources...");
            foreach (var h in _installedHooks)
            {
                try { h.Dispose(); } catch { }
            }
            _installedHooks.Clear();
            Core.Transport.Dispose();
            try { _qaRpcSocket?.Close(); } catch { }
            _qaRpcSocket = null;
        }

        private static bool WasKeyJustPressed(int vk)
        {
            bool isDown = (GetAsyncKeyState(vk) & 0x8000) != 0;
            _keyWasDown.TryGetValue(vk, out bool wasDown);
            _keyWasDown[vk] = isDown;
            return isDown && !wasDown;
        }

        private static void PollHotkeysWithoutInsert()
        {
            // Toggle Co-op Overlay Window: '=' (next to Backspace) or F8
            if (WasKeyJustPressed(VK_OEM_PLUS) || WasKeyJustPressed(VK_F8))
            {
                Core.ShowOverlayWindow = !Core.ShowOverlayWindow;
            }

            // Toggle Bot Test Mode (1 PC): '-' (next to 0) or F6
            if (WasKeyJustPressed(VK_OEM_MINUS) || WasKeyJustPressed(VK_F6))
            {
                if (Core.Role == SessionRole.BotTest)
                {
                    Core.Role = SessionRole.Offline;
                    Core.LogEvent("HOTKEY_BOT_OFF", "offline");
                }
                else
                {
                    Core.Transport.Stop();
                    Core.Role = SessionRole.BotTest;
                    Core.LogEvent("HOTKEY_BOT_ON", $"outfit={Core.PartnerOutfitId}");
                }
            }

            // Cycle Partner Musashi Outfit: ']' or F7
            if (WasKeyJustPressed(VK_OEM_6) || WasKeyJustPressed(VK_F7))
            {
                Core.CyclePartnerOutfit();
            }

            // Toggle Online Host (UDP 27095): '[' or F5
            if (WasKeyJustPressed(VK_OEM_4) || WasKeyJustPressed(VK_F5))
            {
                if (Core.Role == SessionRole.Host)
                {
                    Core.Transport.Stop();
                    Core.Role = SessionRole.Offline;
                }
                else
                {
                    Core.Role = SessionRole.Host;
                    Core.Transport.StartHost(Core.Port);
                    Core.LogEvent("HOTKEY_HOST_ON", $"port={Core.Port}");
                }
            }
        }

        private static void InstallTdbHooks()
        {
            var tdb = TDB.Get();
            if (tdb == null) return;

            HookMethodPre(tdb, "app.SaveDataManager", "requestSaveBase", OnPreSaveRequest);
            HookMethodPre(tdb, "app.SaveDataManager", "requestAutoSave", OnPreSaveRequest);
            HookMethodPre(tdb, "app.SaveDataManager", "requestManualUserSave", OnPreSaveRequest);
            HookMethodPre(tdb, "app.GameFlowManager", "transitIngameToGameOver", OnPreGameOverTransition);
            HookMethodPre(tdb, "app.SoulManager", "addSoulAmountReserve", OnPreAddSoulAmountReserve);
            HookMethodPre(tdb, "app.StoryManager", "onStoryFlag", OnPreStoryFlagSet);
        }

        private static void HookMethodPre(TDB tdb, string typeName, string methodName, MethodHook.PreHookDelegate preDel)
        {
            try
            {
                var td = tdb.FindType(typeName);
                var method = td?.FindMethod(methodName);
                if (method != null)
                {
                    var hook = method.AddHook(false);
                    if (hook != null)
                    {
                        hook.AddPre(preDel);
                        _installedHooks.Add(hook);
                        API.LogInfo($"[OnimushaWotSCoop] Hooked {typeName}.{methodName}");
                    }
                }
            }
            catch (Exception ex)
            {
                API.LogWarning($"[OnimushaWotSCoop] Could not hook {typeName}.{methodName}: {ex.Message}");
            }
        }

        private static PreHookResult OnPreSaveRequest(Span<ulong> args)
        {
            if (Core.ShouldBlockGameSave("app.SaveDataManager.requestSave"))
                return PreHookResult.Skip;
            return PreHookResult.Continue;
        }

        private static PreHookResult OnPreGameOverTransition(Span<ulong> args)
        {
            float clampedHp = 1.0f;
            if (Core.OnLocalPlayerFatalDamage(ref clampedHp))
                return PreHookResult.Skip;
            return PreHookResult.Continue;
        }

        private static PreHookResult OnPreAddSoulAmountReserve(Span<ulong> args)
        {
            if (args.Length >= 3)
            {
                int amount = (int)args[2];
                if (amount > 0 && amount < 1000000)
                {
                    Core.BroadcastSharedRedSouls(amount);
                }
            }
            return PreHookResult.Continue;
        }

        private static PreHookResult OnPreStoryFlagSet(Span<ulong> args)
        {
            if (args.Length >= 3)
            {
                int flagId = (int)args[2];
                Core.BroadcastStoryFlag(flagId, 1);
            }
            return PreHookResult.Continue;
        }

        private static void StartQaRpcBridge()
        {
            try
            {
                _qaRpcSocket = new UdpClient(new IPEndPoint(IPAddress.Loopback, 27099));
                _qaRpcSocket.Client.Blocking = false;
            }
            catch { }
        }

        private static DateTime _lastStatusWrite = DateTime.MinValue;
        private static readonly string StatusFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "reframework", "logs", "coop_status.json");
        private static readonly string CmdFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "reframework", "logs", "coop_cmd.txt");
        private const string WorkspaceCmdFilePath = @"C:\Users\Rique\.gemini\antigravity\scratch\onimusha-wots-coop\local\coop_cmd.txt";

        private static void ApplyBridgeCommand(string cmd)
        {
            if (cmd == "BOT_ON")
            {
                Core.Role = SessionRole.BotTest;
                Core.LogEvent("BRIDGE_BOT_ON", $"outfit={Core.PartnerOutfitId}");
            }
            else if (cmd == "HOST_ON")
            {
                Core.Role = SessionRole.Host;
                Core.Transport.StartHost(Core.Port);
            }
            else if (cmd == "TOGGLE_UI")
            {
                Core.ShowOverlayWindow = !Core.ShowOverlayWindow;
            }
            else if (cmd.StartsWith("OUTFIT:"))
            {
                if (int.TryParse(cmd.Substring(7), out int outfitId))
                    Core.PartnerOutfitId = outfitId;
            }
        }

        private static string BuildStatusJson()
        {
            var inv = CultureInfo.InvariantCulture;
            return
                $"{{\"role\":\"{Core.Role}\",\"saveGuard\":{(Core.SaveGuardActive ? "true" : "false")}," +
                $"\"saveBlocked\":{Core.SaveGuardBlockedCount},\"playerMgr\":{(Core.PlayerManagerFound ? "true" : "false")}," +
                $"\"enemyMgr\":{(Core.EnemyManagerFound ? "true" : "false")},\"soulMgr\":{(Core.SoulManagerFound ? "true" : "false")}," +
                $"\"storyMgr\":{(Core.StoryManagerFound ? "true" : "false")},\"warpMirror\":{(Core.WarpMirrorFound ? "true" : "false")}," +
                $"\"localPlayerAddr\":\"0x{Core.LocalPlayerAddress:X}\",\"partnerCloneAddr\":\"0x{Core.PartnerCloneAddress:X}\"," +
                $"\"posX\":{Core.LocalState.PosX.ToString("F2", inv)},\"posY\":{Core.LocalState.PosY.ToString("F2", inv)},\"posZ\":{Core.LocalState.PosZ.ToString("F2", inv)}," +
                $"\"partnerOutfit\":{Core.PartnerOutfitId},\"staleRejected\":{Core.Ownership.StalePacketsRejected}," +
                $"\"sharedSouls\":{Core.SharedRedSoulsTotal}}}";
        }

        private static void PollQaRpcBridge()
        {
            foreach (string path in new[] { CmdFilePath, WorkspaceCmdFilePath })
            {
                try
                {
                    if (File.Exists(path))
                    {
                        string fileCmd = File.ReadAllText(path).Trim();
                        File.Delete(path);
                        if (!string.IsNullOrEmpty(fileCmd))
                            ApplyBridgeCommand(fileCmd);
                    }
                }
                catch { }
            }

            DateTime now = DateTime.UtcNow;
            if ((now - _lastStatusWrite).TotalSeconds >= 0.5)
            {
                _lastStatusWrite = now;
                try
                {
                    File.WriteAllText(StatusFilePath, BuildStatusJson(), Encoding.UTF8);
                }
                catch { }
            }

            if (_qaRpcSocket == null) return;
            try
            {
                if (_qaRpcSocket.Available <= 0) return;
                IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                byte[] reqBytes = _qaRpcSocket.Receive(ref ep);
                string cmd = Encoding.UTF8.GetString(reqBytes).Trim();
                ApplyBridgeCommand(cmd);
                byte[] resp = Encoding.UTF8.GetBytes(BuildStatusJson());
                _qaRpcSocket.Send(resp, resp.Length, ep);
            }
            catch { }
        }

        [Callback(typeof(UpdateBehavior), CallbackType.Pre)]
        public static void OnUpdateBehavior()
        {
            DateTime now = DateTime.UtcNow;
            float dt = (float)Math.Clamp((now - _lastTick).TotalSeconds, 0.001, 0.1);
            _lastTick = now;

            PollHotkeysWithoutInsert();
            PollQaRpcBridge();

            var playerMgr = API.GetManagedSingleton("app.PlayerManager");
            var enemyMgr = API.GetManagedSingleton("app.EnemyManager");
            var soulMgr = API.GetManagedSingleton("app.SoulManager");
            var storyMgr = API.GetManagedSingleton("app.StoryManager");
            var warpMgr = API.GetManagedSingleton("app.WarpMirrorSpaceManager");

            Core.PlayerManagerFound = playerMgr != null;
            Core.EnemyManagerFound = enemyMgr != null;
            Core.SoulManagerFound = soulMgr != null;
            Core.StoryManagerFound = storyMgr != null;
            Core.WarpMirrorFound = warpMgr != null;

            if (playerMgr != null)
            {
                Core.SyncLocalPlayerFromEngine(playerMgr);
            }

            if (Core.Role == SessionRole.BotTest)
            {
                Core.UpdateBotPeer(dt);
            }
            else if (Core.Role == SessionRole.Host || Core.Role == SessionRole.Client)
            {
                byte selfPeer = (byte)(Core.Role == SessionRole.Client ? 1 : 0);
                Core.Transport.Send(PacketType.PlayerState, selfPeer, in Core.LocalState);
                Core.ProcessNetworkIncoming(soulMgr, storyMgr);
            }
        }

        // Renders even when REFramework's own menu is closed (no Insert key needed!)
        [Callback(typeof(ImGuiRender), CallbackType.Pre)]
        public static void OnImGuiRender()
        {
            if (!Core.ShowOverlayWindow) return;
            DrawCoopWindow();
        }

        [Callback(typeof(ImGuiDrawUI), CallbackType.Pre)]
        public static void OnImGuiDrawUI()
        {
            if (Core.ShowOverlayWindow) return; // Avoid double-drawing if already drawn in ImGuiRender
            DrawCoopWindow();
        }

        private static void DrawCoopWindow()
        {
            if (!ImGui.Begin("Onimusha: Way of the Sword — Co-op Anything (Sem precisar de Insert!)"))
            {
                ImGui.End();
                return;
            }

            ImGui.TextColored(new Vector4(0.3f, 1.0f, 0.5f, 1.0f),
                $"Status: {Core.Role} | Save Guard: {(Core.SaveGuardActive ? "ATIVO (Protegido)" : "Desativado")}");
            ImGui.TextColored(new Vector4(1.0f, 0.9f, 0.4f, 1.0f),
                "Atalhos Rapidos (Sem Insert): [= ou F8] Mostrar/Ocultar | [- ou F6] Modo Bot | [] ou F7] Traje P2 | [[ ou F5] Host");
            ImGui.Separator();

            ImGui.Text("1. Modo de Sessao Cooperativa:");
            if (ImGui.Button("Offline"))
            {
                Core.Transport.Stop();
                Core.Role = SessionRole.Offline;
            }
            ImGui.SameLine();
            if (ImGui.Button("Hospedar ([ ou F5)"))
            {
                Core.Role = SessionRole.Host;
                Core.Transport.StartHost(Core.Port);
                Core.LogEvent("HOST_START", $"port={Core.Port}");
            }
            ImGui.SameLine();
            if (ImGui.Button("Conectar (Client)"))
            {
                Core.Role = SessionRole.Client;
                Core.Transport.ConnectClient(Core.TargetIp, Core.Port);
                Core.LogEvent("CLIENT_CONNECT", $"ip={Core.TargetIp}:{Core.Port}");
            }
            ImGui.SameLine();
            if (ImGui.Button("Modo Bot (- ou F6)"))
            {
                Core.Transport.Stop();
                Core.Role = SessionRole.BotTest;
                Core.LogEvent("BOT_MODE_START", $"outfit={Core.PartnerOutfitId}");
            }

            string ip = Core.TargetIp;
            if (ImGui.InputText("IP do Host (LAN / VPN / Localhost)", ref ip, 64))
                Core.TargetIp = ip;

            ImGui.Separator();

            ImGui.Text("2. Traje do Jogador 2 — Miyamoto Musashi (] ou F7 para alternar):");
            for (int i = 0; i < MusashiOutfits.Catalog.Length; i++)
            {
                var entry = MusashiOutfits.Catalog[i];
                bool selected = Core.PartnerOutfitId == entry.Id;
                if (ImGui.RadioButton(entry.Name, selected))
                {
                    Core.SelectedOutfitIndex = i;
                    Core.PartnerOutfitId = entry.Id;
                    Core.LogEvent("P2_OUTFIT_CHANGE", $"id={entry.Id} name={entry.Name}");
                }
            }

            ImGui.Separator();

            ImGui.Text("3. Regras da Campanha & Balanceamento Genma:");
            float hpMult = Core.EnemyHpMultiplier;
            if (ImGui.SliderFloat("Multiplicador de HP (Genma/Chefes)", ref hpMult, 1.0f, 3.0f))
                Core.EnemyHpMultiplier = hpMult;

            float rkMult = Core.EnemyRikidoMultiplier;
            if (ImGui.SliderFloat("Multiplicador de Postura (Rikido)", ref rkMult, 1.0f, 2.5f))
                Core.EnemyRikidoMultiplier = rkMult;

            bool shareSouls = Core.ShareRedSouls100Percent;
            if (ImGui.Checkbox("Compartilhar 100% das Almas Vermelhas (SoulManager)", ref shareSouls))
                Core.ShareRedSouls100Percent = shareSouls;

            bool downedRevive = Core.EnableDownedRevive;
            if (ImGui.Checkbox("Queda & Reanimacao (1 HP + 3s proximo ao parceiro)", ref downedRevive))
                Core.EnableDownedRevive = downedRevive;

            bool saveGuard = Core.SaveGuardActive;
            if (ImGui.Checkbox("Save Guard (Bloquear gravacao em GSE Saves\\2638890)", ref saveGuard))
                Core.SaveGuardActive = saveGuard;

            ImGui.Separator();

            ImGui.Text("4. Telemetria TDB v82 & Rede:");
            ImGui.Text(
                $"Singletons: PlayerMgr={(Core.PlayerManagerFound ? "OK" : "..")} | " +
                $"EnemyMgr={(Core.EnemyManagerFound ? "OK" : "..")} | " +
                $"SoulMgr={(Core.SoulManagerFound ? "OK" : "..")} | " +
                $"StoryMgr={(Core.StoryManagerFound ? "OK" : "..")} | " +
                $"WarpMirror={(Core.WarpMirrorFound ? "OK" : "..")}");
            ImGui.Text(
                $"P1 Pos: ({Core.LocalState.PosX:F1}, {Core.LocalState.PosY:F1}, {Core.LocalState.PosZ:F1}) | " +
                $"P2 Clone Addr: 0x{Core.PartnerCloneAddress:X}");
            ImGui.Text(
                $"Pacotes TX/RX: {Core.Transport.PacketsSent}/{Core.Transport.PacketsReceived} | " +
                $"Epocas Antigas Rejeitadas: {Core.Ownership.StalePacketsRejected}");
            ImGui.Text(
                $"Almas Compartilhadas: {Core.SharedRedSoulsTotal} | " +
                $"Saves Bloqueados pelo Save Guard: {Core.SaveGuardBlockedCount}");

            ImGui.End();
        }
    }
}
